package com.flp.ems.dao;
import java.util.ArrayList;

import com.flp.ems.domain.Employee;

import javafx.scene.control.TableCellBuilder;
public class EmployeeDaoImplForList implements IemployeeDao {
	private ArrayList<Employee> employeelist;
	public EmployeeDaoImplForList() {
		super();
		employeelist=new ArrayList<Employee>();
	}
	public void addEmployee(Employee employee)
    {
    	employeelist.add(employee);
    }
    public Employee getCloneObject(int employeeId) throws CloneNotSupportedException
    {
    	Employee employee=null;
        for(Employee e:employeelist)
    	{
    		if(e.getEmployeeId()==employeeId)
    			employee=(Employee)e.clone();
    	}
        return employee;
    }
	public void modifyEmployee()
    {
    	
    }
    public void removeEmplyee(Employee employee)
    {
    	boolean b=employeelist.remove(employee);
    	if(b)
    		System.out.println("Employee successfully removed");
    	else
    		System.out.println("something went wrong in Dao Layer");
    }
    
    public Employee searchEmployee(int employeeId)
    {    Employee employee=null;
    for(Employee e:employeelist)
	{
		if(e.getEmployeeId()==employeeId)
			employee=e;
	}
    	return employee;
    }
    public void showAllEmployee()
    {    System.out.println("Employee List :\n");
         //TableBuilder 
         System.out.println("KinId       EmailId       Name       RolesId      DepartmentId     ProjectId");
    	for(Employee e:employeelist)
    	{
    		System.out.println(e.getKinId()+"  "+e.getEmailId()+"  "+e.getName()+"  "+e.getRolesId()+"  "+e.getDepartmentId()+"  "+e.getProjectId());
    	}
    }
	
}
