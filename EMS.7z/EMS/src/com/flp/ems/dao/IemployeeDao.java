package com.flp.ems.dao;

import com.flp.ems.domain.Employee;

public interface IemployeeDao {
	public void addEmployee(Employee employee);
	   
    public void modifyEmployee();
   
    public void removeEmplyee(Employee emp);
  
    
    public Employee searchEmployee(int id);
   
    public void showAllEmployee();
}
