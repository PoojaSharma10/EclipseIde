package com.flp.ems.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Employee implements Cloneable
{   
    private int EmployeeId,PhoneNo,DepartmentId,ProjectId,RolesId;
    private String Name,KinId,EmailId,Address;
    private Date DateOfBirth,DateOfjoining;
    
	public Employee() {
		super();
	}
	public Object clone()throws CloneNotSupportedException{  
		return super.clone();  
		} 
	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}

	public Employee(int employeeId, int phoneNo, int departmentId, int projectId, int rolesId, String name,
			String kinId, String emailId, String address, Date dateOfBirth, Date dateOfjoining) {
		super();
		EmployeeId = employeeId;
		PhoneNo = phoneNo;
		DepartmentId = departmentId;
		ProjectId = projectId;
		RolesId = rolesId;
		Name = name;
		KinId = kinId;
		EmailId = emailId;
		Address = address;
		DateOfBirth = dateOfBirth;
		DateOfjoining = dateOfjoining;
	}

	public int getEmployeeId() {
		return EmployeeId;
	}
	public void setEmployeeId(int employeeId) {
		EmployeeId = employeeId;
	}
	public int getPhoneNo() {
		return PhoneNo;
	}
	public void setPhoneNo(int phoneNo) {
		PhoneNo = phoneNo;
	}
	public int getDepartmentId() {
		return DepartmentId;
	}
	public void setDepartmentId(int departmentId) {
		DepartmentId = departmentId;
	}
	public int getProjectId() {
		return ProjectId;
	}
	public void setProjectId(int projectId) {
		ProjectId = projectId;
	}
	public int getRolesId() {
		return RolesId;
	}
	public void setRolesId(int rolesId) {
		RolesId = rolesId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getKinId() {
		return KinId;
	}
	public void setKinId(String kinId) {
		KinId = kinId;
	}
	public String getEmailId() {
		return EmailId;
	}
	public void setEmailId(String emailId) {
		EmailId = emailId;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public Date getDateOfBirth() {
		return DateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		DateOfBirth = dateOfBirth;
	}
	public Date getDateOfjoining() {
		return DateOfjoining;
	}
	public void setDateOfjoining(Date dateOfjoining) {
		DateOfjoining = dateOfjoining;
	}
    
    
    
    
    
    
    
    
    
}
