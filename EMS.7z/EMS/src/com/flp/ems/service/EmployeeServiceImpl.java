package com.flp.ems.service;

import java.util.Date;
import java.util.HashMap;

import com.flp.ems.dao.EmployeeDaoImplForList;
import com.flp.ems.domain.Employee;

public class EmployeeServiceImpl implements IEmployeeService{
	HashMap<String, Object> hashmap;
	EmployeeDaoImplForList employeeDaoImplForList;
	
	public EmployeeServiceImpl() {
		super();
		employeeDaoImplForList = new EmployeeDaoImplForList();
		}
	public EmployeeServiceImpl(HashMap<String, Object> hashmap)
	{ this.hashmap=hashmap;
	}
	public void addEmployee()
    {
    	Employee employee=new  Employee(
    			(int)hashmap.get("EmployeeId"),
    			(int)hashmap.get("PhoneNo"),
    			(int)hashmap.get("DepartmentId"),
    			(int)hashmap.get("ProjectId"),
    			(int) hashmap.get("RolesId"),
    			(String)  hashmap.get("Name"),
    			 (String)hashmap.get("KinId"),
    			(String)hashmap.get("EmailId"),
    		(String)hashmap.get("Address"),
    		(Date)hashmap.get("DateOfBirth"),
    		 (Date)hashmap.get("DateOfjoining"));
    	/*employee.setEmployeeId((int)hashmap.get("EmployeeId"));
    	employee.setPhoneNo((int)hashmap.get("PhoneNo")) ;
    	employee.setAddress((String)hashmap.get("Address"));
    	employee.setDepartmentId((int)hashmap.get("DepartmentId")) ;
    	employee.setProjectId((int)hashmap.get("ProjectId"));
    	employee.setRolesId((int) hashmap.get("RolesId"));
    	employee.setName((String)  hashmap.get("Name")) ;
    	employee.setKinId((String) kinId);
    	employee.setEmailId(String emailId) ;
    	employee.setAddress(String address) ;
    	employee.setDateOfBirth(Date dateOfBirth);
    	employee.setDateOfjoining(Date dateOfjoining)*/
    	employeeDaoImplForList.addEmployee(employee);
    	
    }
    public void modifyEmployee(int employeeId,HashMap<String, Object>hashmap) throws CloneNotSupportedException
    { Employee employee=employeeDaoImplForList.getCloneObject(employeeId);
      
    	
    }
    public void removeEmplyee(int employeeId)
    {  Employee employee=searchEmployee(employeeId);
      if(employee!=null)
    	employeeDaoImplForList.removeEmplyee(employee);
    }
    
    public Employee searchEmployee(int employeeId)
    {
    	return employeeDaoImplForList.searchEmployee(employeeId);
    }
    public void showAllEmployee()
    {
    	employeeDaoImplForList.showAllEmployee();
    }
}
