package com.flp.ems.view;

import java.util.Scanner;

public class BootClass {

	public static void menuSelection() throws CloneNotSupportedException {
		Scanner sc = new Scanner(System.in);
		int input = sc.nextInt();
		UserInteraction userinteraction = new UserInteraction();
		switch (input) {
		case 1:
			userinteraction.addEmployee();
			break;
		case 2:
			userinteraction.modifyEmployee();
			break;
		case 3:
			userinteraction.searchEmployee();
			break;
		case 4:
			userinteraction.removeEmplyee();
			break;
		case 5:
			userinteraction.showAllEmployee();
			break;
		default:
			System.out.println("Invalid Input");

		}

	}

	public static void main(String[] args) throws CloneNotSupportedException {
		System.out.println("Select Appropriate Choice");
		System.out.println("Press 1 to add a new employee");
		System.out.println("Press 2 to modify existing employee details");
		System.out.println("Press 3 to remove employee from system");
		System.out.println("Press 4 to search existing employee");
		System.out.println("Press 5 to get employee list");
		menuSelection();
	}

}
