class JJF6 {
    String a = "abcd";          // 1
    String b = "'\u0041'";      // 2
    String c = "\u0041";        // 3
    String d = "\uD7AF";        // 4

}
