package linkedlist;

public class LinkedList {
     Node root;
	class Node
	{
		private int data;
		private Node next;
		public Node()
		{}
		public Node(int data)
		{
		this.data=data;
		this.next=null;
		}
	}
	public LinkedList()
	{
		//root=new Node();
		root=null;
	}
	
	public Node createNode(int data)
	{
		Node node=new Node(data);
		return node;
	}
	public void add(int data)
	{
		Node n=createNode(data);
		if(root==null)
			{root=n;return;}
	    Node temp=root;
	    while(temp.next!=null)
	    	temp=temp.next;
	    temp.next=n;
	}
	public void traverse()
	{   Node temp=root;
	   if(temp==null)
	   {System.out.println("empty\n");return;}
	    while(temp!=null)
	    {
	    	System.out.println(temp.data);
	    	temp=temp.next;
	    }
	}
	public void delete()
	{
		Node temp=root;
		while(temp.next!=null)
		{
			Node n=temp;
			temp=temp.next;
			System.out.println("deleted node-"+n.data);
			n=null;
		}
		root=null;
	}

}
