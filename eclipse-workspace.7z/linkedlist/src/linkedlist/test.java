package linkedlist;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList linkedlist=new LinkedList();
        linkedlist.add(5);
        linkedlist.add(6);
        linkedlist.add(7);
        linkedlist.add(8);
        linkedlist.traverse();
        linkedlist.delete();
        linkedlist.traverse();
        
	}

}
