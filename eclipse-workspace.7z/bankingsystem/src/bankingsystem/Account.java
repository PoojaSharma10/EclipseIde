package bankingsystem;

public class Account 
{   private int id;
    double balance=3000.0;
    private String name;
    private teller1 t1;
    private teller2 t2;
    public Account()
    {
    	
    }
    
    public Account(int id,String name)
    {
    	this.id=id;
    	this.name=name;
    }
    public Account(int id,double balance)
    {
    	this.id=id;
    	this.balance=balance;
    }
     public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public synchronized void deposit(double amount) throws InterruptedException
     {  if(amount>0)
         {
    	 balance=this.balance;
    	 balance+=amount;
    	Thread.sleep(3000);
    	 this.balance=balance;
    	 System.out.println(amount+"amount has been deposited into "+id+" account\n");
    	 }
       
     
     }
     public synchronized void withdraw(double amount) throws InterruptedException
     {  double balance;
    	 if(this.balance>amount)
    	 {
    	 balance=this.balance;
    	 balance=balance-amount;
    	 Thread.sleep(10000);
    	 this.balance=balance;
         System.out.println(amount+"amount has been credited from "+id+" account\n");

    	 }
    	 else 
    	 {
    		 System.out.println("customer do not have sufficient balance to withdraw \n");
    	 }
    	 
     }
    
}
