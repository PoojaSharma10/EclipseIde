package bankingsystem;

public class teller2 extends Thread {
	Bank bank;
	   Account fromAccount;
	   Account toAccount;
	   double amount;
	   teller2(Account fromAccount,Account toAccount,double amount)
	   {
		   bank=new Bank();
		   this.fromAccount=fromAccount;
		   this.toAccount=toAccount;
		  this.amount=amount;
	   }
	   
	   public void run()
	   {
		   try {System.out.println("before :\n");
		 
		    Bank.showAccountBalance(fromAccount);
		    Bank.showAccountBalance(toAccount);
			bank.transferAmount(fromAccount, toAccount, amount);
			System.out.println("After :\n");
		    Bank.showAccountBalance(fromAccount);
		    Bank.showAccountBalance(toAccount);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		   System.out.println("Teller1:"+amount+" has been transferred from account "+fromAccount.getId()+"to"+toAccount.getId());
	   }}