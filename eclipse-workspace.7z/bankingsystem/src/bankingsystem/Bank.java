package bankingsystem;

import java.util.ArrayList;

public class Bank
{  ArrayList<Account> accountList;

   Bank()
   { 
	   accountList=new ArrayList<Account>();
   }
   public void addAccount(String name,int id)
   {
	   Account a=new Account(id,name);
	   accountList.add(a);
	  // System.out.println("added");
   }
	public static void showAccountBalance(Account account)
   {
	 System.out.println("Customer Account has "+account.balance+"Balance\n");
   }
	public Account getAccount(int id)
    {
    	return accountList.get(id);
    }
	void transferAmount(Account fromAccount,Account toAccount,double amount) throws InterruptedException
	   {   
		
		  fromAccount.withdraw(amount);
			Thread.sleep(1000);
			toAccount.deposit(amount);
		   
	   }
}
