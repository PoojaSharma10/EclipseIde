package bankingsystem;

public class Test {

	public static void main(String[] args) throws InterruptedException 
	{
		Bank b=new Bank();
		b.addAccount("Shirii", 1);
		b.addAccount("Pooja", 2);
		b.addAccount("rishika",3);
		Account src=b.getAccount(1);
		Account dest=b.getAccount(2);
		Thread t1,t2;
		 t1=new teller1(src,dest, 500.0);
		  t2=new teller2(dest,src,500.0);
		 t1.start();
	      t2.start();

	}

}
