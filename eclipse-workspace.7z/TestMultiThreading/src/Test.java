class Test 
{  
  public static void main(String args[])
  {  
    Thread t1=new Thread(new MyThread()); 
	//MyThread t1= (MyThread) new Thread();
    // t1.start();  
    t1.run(); 
  t1.start();  
 }  
}  