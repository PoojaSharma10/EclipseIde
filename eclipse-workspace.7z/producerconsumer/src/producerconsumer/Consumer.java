package producerconsumer;

import java.util.Vector;

public class Consumer extends Thread
{
      final Container container;
     final int size;
	public Consumer(Container container) {
		this.container=container;
		this.size=container.size;
		
	}
	
	@Override
	public void run() {
		try {container.remove();
			//System.out.println("Element "++"removed\n");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
