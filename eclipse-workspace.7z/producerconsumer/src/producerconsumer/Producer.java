package producerconsumer;

import java.util.Scanner;
import java.util.Vector;

public class Producer extends Thread
{

	final Container container;
    final int size;
	public Producer(Container container) {
		this.container=container;
		this.size=container.size;
		
	}
	
	@Override
	public void run() {
		try {/*System.out.println("Enter no to produce\n");
		 Scanner sc=new Scanner(System.in);
		 int x=sc.nextInt();*/
			container.add(13);
		//	System.out.println("Element added\n");
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
