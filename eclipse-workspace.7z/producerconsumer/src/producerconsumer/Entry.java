package producerconsumer;

import java.util.Vector;

public class Entry 
{
    
	public static void main(String[] args)
	{
        Container container=new Container();
        Thread pro=new Producer(container);
      Thread cons=new Consumer(container);
      Thread pro1=new Producer(container);
      Thread cons1=new Consumer(container);
      Thread pro2=new Producer(container);
      Thread cons2=new Consumer(container);
        pro.start();
       cons.start(); 		
	}

}
