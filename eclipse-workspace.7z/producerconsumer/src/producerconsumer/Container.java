package producerconsumer;

public class Container {
	int x[];
	int size,index;

	Container() {
		
		x = new int[5];
		index=0;
	}

	synchronized void add(int x) throws InterruptedException {
		while (this.size == 5) {
			System.out.println("Producer will wait\n");
			this.wait();
		}
		this.x[index] = x;
		index++;size++;
		System.out.println("item is produced\n");
		this.notify();

	}

	synchronized int remove() throws InterruptedException {
		while (this.size == 0) {
			System.out.println("Consumer will wait\n");
			this.wait();
		}
		int x = this.x[--index];
		size--;
		System.out.println("item is consumed");
		this.notify();
		return x;
		
	}
}
