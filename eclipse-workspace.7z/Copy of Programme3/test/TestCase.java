
import static org.junit.Assert.*;

import org.junit.*;
public class TestCase {

	@Test
	@Ignore
	public void test() {
		fail("Not yet implemented");
	//	Thread
	}
	
    @Test
	
	public void testSecong() {
		String msg=new String("Hello!world");
		String msg1="Hello!worlda";//interned String
		String msg2="Hello!worlda";
       // Assert.assertSame(msg, msg1);
        Assert.assertEquals(msg, msg1);
	 
	}
}
