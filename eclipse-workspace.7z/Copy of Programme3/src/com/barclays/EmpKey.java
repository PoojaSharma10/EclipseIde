package com.barclays;

public class EmpKey  implements Comparable<EmpKey>
{
  int id;
  static int inc=1;
   StringBuffer suffix=new StringBuffer("EA_");
 public EmpKey()
  {   
	
	 inc++;
	 id=inc;
	 suffix.setCharAt(1,(char)(suffix.charAt(1)+inc-1));
	
  }
  public EmpKey(int id,StringBuffer s)
  {
	 this.id=id;
	 this.suffix=s;
  }
  public String toString()
  {
	  return new String(suffix)+id;
  }
 /* */
@Override
public int compareTo(EmpKey o) {
	// TODO Auto-generated method stub
	//System.out.println(this.id+"compare"+o.id);
   int diff=this.id-o.id;
   return -diff;
}
void fun()
{final int x;}
}
