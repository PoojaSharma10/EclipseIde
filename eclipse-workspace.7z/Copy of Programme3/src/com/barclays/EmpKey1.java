package com.barclays;

public class EmpKey1 
{ int id;
static int inc=1;
StringBuffer suffix=new StringBuffer("EA_");
public EmpKey1()
{   
	
	 inc++;
	 id=inc;
	 suffix.setCharAt(1,(char)(suffix.charAt(1)+inc-1));
	
}
public EmpKey1(int id,StringBuffer s)
{
	 this.id=id;
	 this.suffix=s;
}
public String toString()
{
	  return new String(suffix)+id;
}
  @Override
public int hashCode()
  {
	// TODO Auto-generated method stub
	return super.hashCode();
  }
  @Override
	public boolean equals(Object obj) 
  {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}
}
