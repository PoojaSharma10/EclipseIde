package com.barclays;

public class EmployeeNotFoundException extends Exception
{

	
		//String msg;

		public EmployeeNotFoundException(String msg) {
			super(msg);
			
		}
		
}

