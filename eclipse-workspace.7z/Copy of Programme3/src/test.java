import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import com.barclays.EmpKey1;
import com.barclays.Employee;
import com.barclays.EmployeeNotFoundException;
import com.barclays.Permanant.PermanantEmployee;
import com.barclays.contractbased.ContractBasedEmployee;
import com.date.Date;

public class test {
	/*public static boolean checkID(Employee e[], int x) throws EmployeeNotFoundException {
		for (Employee emp : e) {
			if (emp.getID() == x)
				return true;
		}
		
		throw new EmployeeNotFoundException("EmployeeNotFoundException");
	}*/
	public boolean search(EmpKey1 ek,HashMap<EmpKey1,Employee>map)
    { if(map.containsKey(ek)==null)
      	 return false;
    }
	public static void main(String[] args) throws EmployeeNotFoundException {
		/*
		 * System.out.println(d1); PermanantEmployee e=new
		 * PermanantEmployee(d1,20000);
		 * e.setData("Pooja","Sharma","developer",500); e.getData();
		 * 
		 * Date d2=new Date(1,8,2015); ContractBasedEmployee e1=new
		 * ContractBasedEmployee(d2,1000,8);
		 * e1.setData("Neha","Gupta","Designer",500); e1.getData();
		 * 
		 * 
		 * Employee.getNoOfEmployee(); Employee.getNoOfPermanantEmployee();
		 * Employee.getNoOfContractBasedEmployee(); Integer x=5+new Integer(6);
		 */



	/*	String s[] = { "pooja", "neha", "rupali", "smriti", "aastha" };
		Employee e[] = new Employee[5];
		Date d1;
		Map<EmpKey,Employee> map=new TreeMap<EmpKey,Employee>();
		
		for (int i = 0; i < 5; i++) 
		{
			d1 = new Date(10, 7, 2016);
			e[i] = new Employee(d1, 50000);
			e[i].setData(s[i], "Sharma", "developer", 500);
			map.put(e[i].getID(),e[i]);
		}
		Set<Map.Entry<EmpKey,Employee>>set=map.entrySet();
		for(Map.Entry<EmpKey, Employee> entry:set)
		{
			System.out.println(entry.getKey()+"  "+entry.getValue()+"\n");
		}
		Employee emp;
		try { emp=map.get(new EmpKey(3,new StringBuffer("EA_")));
		    if(emp!=null)
		    {
		    	System.out.println(emp);
		    }
		    else
		    {
		    	throw new EmployeeNotFoundException("Employee not found");
		    }
		    emp=map.get(new EmpKey(9,new StringBuffer("EA_")));
		    if(emp!=null)
		    {
		    	System.out.println(emp);
		    }
		    else
		    {
		    	throw new EmployeeNotFoundException("Employee not found");
		    }

			
		} catch (EmployeeNotFoundException exp) {
			System.out.println(exp.getMessage());
		}*/

		String s[] = { "pooja", "neha", "rupali", "smriti", "aastha" };
			Employee e[] = new Employee[5];
			Date d1;
		Map<EmpKey1,Employee> map=new HashMap<EmpKey1,Employee>();
		for (int i = 0; i < 5; i++) 
		{
			d1 = new Date(10, 7, 2016);
			e[i] = new Employee(d1, 50000);
			e[i].setData(s[i], "Sharma", "developer", 500);
			map.put(e[i].getID(),e[i]);
		}
		for(Map.Entry m:map.entrySet())
		{
			System.out.println(m.getKey()+" "+m.getValue()+"\n");
		}
		EmpKey1 ek=new EmpKey1(3,new StringBuffer("EC_"));
        new test().search(ek,map);
	}

}
