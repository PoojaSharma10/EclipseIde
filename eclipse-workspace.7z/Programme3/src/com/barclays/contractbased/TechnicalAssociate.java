package com.barclays.contractbased;

public class TechnicalAssociate extends ContractBasedEmployee
{

}
