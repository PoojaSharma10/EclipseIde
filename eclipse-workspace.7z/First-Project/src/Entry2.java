

public class Entry2 {

	public static void main(String[] args) 
	{
      		

	}

}
