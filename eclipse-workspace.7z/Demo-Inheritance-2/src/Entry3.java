import com.simulationdemo.Contractor;

public class Entry3 {
	public static void main(String[] args) {
		Contractor c1 = new Contractor();
//		Contractor.CBEmployee e1 =  c1.new CBEmployee();
		
	}
}
